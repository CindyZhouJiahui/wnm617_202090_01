# Jiahui Zhou

## Links
- https://jiahuizhounygmail.com
- http://jiahuizhounygmail.com/aau/wnm617_2/cindy.zhou/index.html
- http://jiahuizhounygmail.com/aau/wnm617_2/cindy.zhou/initializr/
- http://jiahuizhounygmail.com/aau/wnm617_2/cindy.zhou/Insect/insect.html